<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <link rel="stylesheet" href="scripts/css/login.css">

    <!-- Sweet Alert -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.min.css">

    <title>Login Page</title>
</head>
<body>
    <div id="main-login" class="container d-flex justify-content-center align-items-center min-vh-100">
        <!-- Login -->
        <div v-if="isLogin" class="row border rounded-5 p-3 shadow box-area" style="background: #f6f6f6">
            <!-- Image Placeholder -->
            <div id="login-img" class="image-placeholder col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box">
            </div> 
            <!-- Form -->
            <div class="col-md-6 right-box">
                <div class="row align-items-center">
                    <div class="header-text mb-4">
                        <h2>Welcome back!</h2>
                        <p>Please enter your details.</p>
                    </div>
                    <div class="row">
                        <!-- Username -->
                        <div class="input-group mb-3">
                            <input v-model="username" id="username" name="username" type="text" class="form-control form-control-lg bg-light fs-6" placeholder="Username" required>
                        </div>
                        <!-- Role -->
                        <div class="input-group mb-3">
                            <select v-model="roleSelected" id="role" name="role" class="form-control form-control-lg bg-light fs-6" required>
                                <option disabled value="">--- Select Role ---</option>
                                <option v-for="option in roleOption">
                                    {{ option.text }}
                                </option>
                            </select>
                        </div>
                        <!-- Password -->
                        <div class="input-group mb-4">
                            <input v-model="password" id="password" name="password" type="password" class="form-control form-control-lg bg-light fs-6" placeholder="Password" required>
                        </div>
                        <div class="input-group mb-3">
                            <button id="login" name="login" type="submit" class="btn btn-lg w-100 fs-6" @click="loginValidation()">Login</button>
                        </div>
                    </div>
                    <div class="row">
                        <small>Don't have an account? <b><a href="#" @click="registerAccount()" style="color: #023246">Register now</a></b></small>
                    </div>
                </div>
            </div> 
        </div>

        <!-- Register -->
        <div v-else class="row border rounded-5 p-3 shadow box-area" style="background: #f6f6f6">
            <!-- Image Placeholder -->
            <div id="register-img" class="image-placeholder col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box">
            </div> 
            <!-- Form -->
            <div class="col-md-6 right-box">
                <div class="row align-items-center">
                    <div class="header-text mb-4">
                        <h2>Register!</h2>
                        <p>Create your account. It only takes a minute.</p>
                    </div>
                    <!-- Username -->
                    <div class="input-group mb-3">
                        <input v-model="regUsername" id="regUsername" type="text" class="form-control form-control-lg bg-light fs-6" placeholder="Username" required>
                    </div>
                    <!-- Email -->
                    <div class="input-group mb-3">
                        <input v-model="regEmail" id="regEmail" type="email" class="form-control form-control-lg bg-light fs-6" placeholder="Email" required>
                    </div>
                    <!-- Password -->
                    <div class="input-group mb-3">
                        <input v-model="regPassword" id="regPassword" type="password" class="form-control form-control-lg bg-light fs-6" placeholder="Password" required>
                    </div>
                    <!-- Confirm Password -->
                    <div class="input-group mb-4">
                        <input v-model="regConfirmPassword" id="regConfirmPassword" type="password" class="form-control form-control-lg bg-light fs-6" placeholder="Confirm Password" required>
                    </div>
                    <div class="input-group mb-3">
                        <button id="register" type="submit" class="btn btn-lg w-100 fs-6" @click="registerValidation()">Register</button>
                    </div>
                    <div class="row">
                        <small>Already have an account? <b><a href="#" @click="registerAccount()" style="color: #023246">Login now</a></b></small>
                    </div>
                </div>
            </div> 
        </div>
    </div>

    <script src="scripts/js/vue.min.js"></script>
    <script>
        vue = new Vue({
            el: '#main-login', 
            data: {
                isLogin: true,

                username: '',
                password: '',
                roleSelected: '',
                roleOption: [
                    {value: '0', text: 'Client'}, 
                    {value: '1', text: 'Staff'}
                ],

                regUsername: '',
                regEmail: '',
                regPassword: '',
                regConfirmPassword: ''
            },
            methods: {
                registerAccount() {
                    this.isLogin = !this.isLogin
                },
                loginValidation() {
                    if (this.username != '' && this.roleSelected != '' && this.password != '') {
                        $.ajax({
                            type: 'POST',
                            data: {
                                username: this.username,
                                role: this.roleSelected,
                                password: this.password
                            },
                            url: 'api/login/login.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                if (data['error'] == 0) {
                                    Swal.fire({
                                        title: 'Success', 
                                        icon: 'success', 
                                        text: data['msg'], 
                                        allowOutsideClick: false,
                                        confirmButtonText:'OK', 
                                        willClose:() => {
                                            window.location=data['url_page'];
                                        }
                                    });
                                } else if (data['error'] == 1) {
                                    Swal.fire({
                                        title: 'Error',
                                        text: data['msg'],
                                        icon: 'error',
                                        allowOutsideClick: false,
                                        confirmButtonText:'Close',
                                        willClose:() => {
                                            window.location='index.php';
                                        }
                                    });
                                }
                            }
                        });
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: 'Please fill in all the input fields!',
                            icon: 'error',
                            allowOutsideClick: false,
                            confirmButtonText:'Close'
                        });
                    }
                },
                registerValidation() {
                    if (this.regUsername != '' && this.regEmail != '' && this.regPassword != '' && this.regConfirmPassword != '') {
                        if (this.regPassword == this.regConfirmPassword) {
                            $.ajax({
                                type: 'POST',
                                data: {
                                    username: this.regUsername,
                                    email: this.regEmail,
                                    password: this.regPassword
                                },
                                url: 'api/login/register.php',
                                success: function(res) {
                                    data = JSON.parse(res)

                                    if (data['error'] == 0) {
                                        Swal.fire({
                                            title:'Success', 
                                            icon:'success', 
                                            text: data['msg'], 
                                            allowOutsideClick: false,
                                            confirmButtonText:'OK', 
                                            willClose:() => {
                                                window.location='index.php';
                                            }
                                        });
                                    } else if (data['error'] == 1) {
                                        Swal.fire({
                                            title: 'Error',
                                            text: data['msg'],
                                            icon: 'error',
                                            allowOutsideClick: false,
                                            confirmButtonText:'Close',
                                            willClose:() => {
                                                window.location='index.php';
                                            }
                                        });
                                    }
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Password did not match!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: 'Please fill in all the input fields!',
                            icon: 'error',
                            allowOutsideClick: false,
                            confirmButtonText:'Close'
                        });
                    }
                },
            },
        })
    </script>

    <!-- jQuery -->
    <script src="scripts/js/jquery-3.7.0.min.js"></script>

    <!-- Sweet Alert -->
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.min.js"></script>

    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
</body>
</html>