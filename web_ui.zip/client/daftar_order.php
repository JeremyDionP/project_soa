<?php
    session_start();

    if(!isset($_SESSION['username']) && !isset($_SESSION['id'])){
        header('Location: ../index.php');
    } else {
        echo "<script>var client_id = " . $_SESSION['id'] . ";</script>";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php include 'links.php'; ?>

    <title>Daftar Order</title>
</head>
<body>
    <div id="main">
        <?php include 'navbar.php'; ?>
        
        <div class="container">
            <!-- Add Order -->
            <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addOrderModal">+ Add New Order</button>

            <!-- Staff Table -->
            <table v-if="dataLoaded" id="order-table" class="table table-light" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Contact</th>
                        <th>Event Type</th>
                        <th>Date</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="staff-table-body">
                    <tr v-for="(order, index) in listOrder" :key="order.id">
                        <td>{{ index+1 }}</td>
                        <td>{{ order.contact }}</td>
                        <td>{{ order.event_type }}</td>
                        <td>{{ order.date }}</td>
                        <td>{{ order.location }}</td>
                        <td>
                            <button v-if="order.status == 0" type="button" class="btn btn-danger" disabled>Not Approved</button>
                            <button v-else-if="order.status == 1" type="button" class="btn btn-success" disabled>Approved</button>
                        </td>
                        <td>
                            <button v-if="order.status == 0" type="button" class="btn btn-danger" @click="cancelOrder(order.id)">Cancel Order</button>
                            <button v-else-if="order.status == 1" type="button" class="btn btn-primary" @click="getRundown(order.id)" data-bs-toggle="modal" data-bs-target="#viewRundownModal">View Rundown</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- View Rundown Modal -->
        <div class="modal fade" id="viewRundownModal" tabindex="-1" aria-labelledby="viewRundownModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="viewRundownModalLabel">Rundown</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Rundown Table -->
                        <table v-if="dataRundownLoaded" id="rundown-table" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Start</th>
                                    <th>End</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody id="staff-table-body">
                                <tr v-if="listRundown.length == 0">
                                    <td colspan="4" class="text-center">No rundown added yet.</td>
                                </tr>
                                <tr v-else v-for="(rundown, index) in listRundown" :key="rundown.id">
                                    <td>{{ index+1 }}</td>
                                    <td>{{ rundown.time_start }}</td>
                                    <td>{{ rundown.time_end }}</td>
                                    <td>{{ rundown.description }}</td>
                                </tr>
                            </tbody>
                        </table>
                        <p v-else class="mb-0">There is no rundown.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Order Modal -->
        <div class="modal fade" id="addOrderModal" tabindex="-1" aria-labelledby="addOrderModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addOrderModalLabel">Add New Order</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <!-- Event Type -->
                            <div class="col-12 mb-3">
                                <label for="addEventType" class="form-label">Event Type</label>
                                <select v-model="addEventType" id="addEventType" class="form-control form-control-lg bg-light fs-6" name="addEventType" required>
                                    <option disabled value="">--- Select Event Type ---</option>
                                    <option v-for="type in listEventType" :value="type.id" :key="type.id">
                                        {{ getEventTypeName(type.id) }}
                                    </option>
                                </select>
                            </div>
                            <!-- Contact -->
                            <div class="col-12 mb-3">
                                <label for="addContact" class="form-label">Contact Number</label>
                                <input v-model="addContact" type="tel" class="form-control" id="addContact" name="addContact" required>
                            </div>
                            <!-- Date -->
                            <div class="col-6 mb-3">
                                <label for="addDate" class="form-label">Date</label>
                                <input v-model="addDate" type="date" class="form-control" id="addDate" name="addDate" required>
                            </div>
                            <!-- Time -->
                            <div class="col-6 mb-3">
                                <label for="addTime" class="form-label">Time</label>
                                <input v-model="addTime" id="addTime" type="time" class="form-control" name="addTime" required>
                            </div>
                            <!-- Location -->
                            <div class="col-12">
                                <label for="addLocation" class="form-label">Location</label>
                                <input v-model="addLocation" id="addLocation" type="text" class="form-control form-control-lg bg-light fs-6" name="addLocation" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" @click="addOrder()">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script type="text/javascript">
        $(document).ready(function () {
            // Bootstrap DataTable initialization
            $('#order-table').DataTable()

            vue = new Vue({
                el: '#main', 
                data: {
                    listOrder: [],
                    dataLoaded: false,

                    listEventType: [],

                    listRundown: [],
                    dataRundownLoaded: false,

                    addEventType: '',
                    addContact: '',
                    addDate: '',
                    addTime: '',
                    addLocation: '',
                },
                methods: {
                    // GET list of order data to display
                    getOrders() {
                        // Store reference to the Vue component instance
                        const vm = this

                        // Reset list order
                        this.listOrder = []

                        $.ajax({
                            type: 'GET',
                            url: '../api/order/get_order.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                // vm.listOrder = data
                                vm.dataLoaded = true

                                // Loop through the order list
                                data.forEach(async function(item) {
                                    if (item.client_id == client_id) {
                                        vm.listOrder.push({
                                            id: item.id,
                                            contact: item.contact,
                                            event_type: vm.getEventTypeName(item.event_type_id),
                                            date: item.date,
                                            location: item.location,
                                            status: item.status,
                                        })
                                    }
                                });
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        })
                    },
                    getEventType() {
                        // Store reference to the Vue component instance
                        const vm = this

                        $.ajax({
                            type: 'GET',
                            url: '../api/order/get_event_type.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                vm.listEventType = data
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        });
                    },
                    getEventTypeName(id) {
                        for (var i = 0; i < this.listEventType.length; i++) {
                            if (this.listEventType[i].id == parseInt(id)) {
                                return this.listEventType[i].type
                            }
                        }
                    },
                    // GET Rundown By Order Id
                    getRundown(id) {
                        // Store reference to the Vue component instance
                        const vm = this

                        $.ajax({
                            type: 'GET',
                            data: {
                                order_id: id
                            },
                            url: '../api/event/get_rundown_order_id.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                // update the data
                                vm.listRundown = data
                                vm.dataRundownLoaded = true
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        });
                    },
                    cancelOrder(id) {
                        const vm = this

                        Swal.fire({
                            title: 'Are you sure?',
                            text: "You won't be able to revert this!",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                $.ajax({
                                    type: 'POST',
                                    data: {
                                        order_id: id
                                    },
                                    url: '../api/order/delete_order.php',
                                    success: function(res) {
                                        // Reset table
                                        vm.getOrders()

                                        Swal.fire(
                                            'Deleted!',
                                            'Your order has been deleted.',
                                            'success'
                                        )
                                    },
                                    error: function(xhr, status, error) {
                                        // Handle error
                                        console.log('Error:', error)
                                    }
                                });
                            }
                        })
                    },
                    // POST new order
                    addOrder() {
                        if (this.addEventType != '' && this.addContact != '' && this.addDate != '' && this.addTime != '' && this.addLocation != '') {
                            const vm = this

                            $.ajax({
                                type: 'POST',
                                data: {
                                    client_id: client_id,
                                    event_type_id: this.addEventType,
                                    contact: this.addContact,
                                    date: (this.addDate + ' ' + this.addTime),
                                    location: this.addLocation
                                },
                                url: '../api/order/add_order.php',
                                success: function(res) {
                                    data = JSON.parse(res)

                                    // If there is no error
                                    if (data['error'] == 0) {
                                        Swal.fire({
                                            title:'Success', 
                                            icon:'success', 
                                            text: data['msg'], 
                                            allowOutsideClick: false,
                                            confirmButtonText:'OK', 
                                        });

                                        // Reset input fields
                                        vm.addEventType = ''
                                        vm.addContact = ''
                                        vm.addDate = ''
                                        vm.addTime = ''
                                        vm.addLocation = ''

                                        // Reset table
                                        vm.getOrders()

                                        // Close modal
                                        $('#addOrderModal').modal('toggle');
                                    } else if (data['error'] == 1) {
                                        Swal.fire({
                                            title: 'Error',
                                            text: data['msg'],
                                            icon: 'error',
                                            allowOutsideClick: false,
                                            confirmButtonText:'Close',
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    // Handle error
                                    console.log('Error:', error)
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Please fill in all the input fields!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    },
                },
                mounted() {
                    this.getOrders()
                    this.getEventType()
                }
            })
        });
    </script>
</body>
</html>