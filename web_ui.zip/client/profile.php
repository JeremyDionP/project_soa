<?php
    session_start();

    if(!isset($_SESSION['username']) && !isset($_SESSION['id'])){
        header('Location: ../index.php');
    } else {
        echo "<script>var client_id = " . $_SESSION['id'] . ";</script>";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php include 'links.php'; ?>

    <title>Profile</title>
</head>
<body>
    <div id="main">
        <?php include 'navbar.php'; ?>

        <div v-if="!changePass" class="container profile-container">
            <h1 class="mb-4 d-flex justify-content-center">Your Profile</h1>
            
            <div class="row">
                <!-- Username -->
                <div class="col-12 mb-3">
                    <label for="editUsername" class="form-label">Username</label>
                    <input v-model="editUsername" :disabled="!isEdit" id="editUsername" name="editUsername" type="text" class="form-control form-control-lg bg-light fs-6" required>
                </div>
                <!-- Email -->
                <div class="col-12 mb-3">
                    <label for="editEmail" class="form-label">Email</label>
                    <input v-model="editEmail" :disabled="!isEdit" id="editEmail" type="email" class="form-control form-control-lg bg-light fs-6" required>
                </div>
                <!-- Change Password -->
                <div class="mb-5 d-flex justify-content-end align-items-center">
                    <b><a href="#" @click="changePassword()" style="color: #023246">Change Your Password</a></b>
                </div>
                <div v-if="isEdit" class="d-flex justify-content-center align-items-center">
                    <button type="button" class="btn btn-secondary me-1" @click="editProfile()">Cancel</button>
                    <button id="saveEdit" name="saveEdit" class="btn btn-primary" @click="saveEditProfile()">Save Changes</button>
                </div>
                <div v-else class="d-flex justify-content-center align-items-center">
                    <button id="btnEdit" name="btnEdit" class="btn btn-primary" @click="editProfile()">Edit Profile</button>
                </div>
            </div>
        </div>

        <div v-else-if="changePass" class="container profile-container">
            <h1 class="mb-4 d-flex justify-content-center">Change Password</h1>
            
            <div class="row">
                <!-- Old Password -->
                <div class="col-12 mb-3">
                    <label for="editOldPass" class="form-label">Old Password</label>
                    <input v-model="editOldPass" id="editOldPass" type="password" class="form-control form-control-lg bg-light fs-6" required>
                </div>
                <!-- New Password -->
                <div class="col-12 mb-3">
                    <label for="editNewPass" class="form-label">New Password</label>
                    <input v-model="editNewPass" id="editNewPass" type="password" class="form-control form-control-lg bg-light fs-6" required>
                </div>
                <!-- Confirm Password -->
                <div class="col-12 mb-5">
                    <label for="editConfirmPassword" class="form-label">Confirm Password</label>
                    <input v-model="editConfirmPassword" id="editConfirmPassword" type="password" class="form-control form-control-lg bg-light fs-6" required>
                </div>
                <div class="d-flex justify-content-center align-items-center">
                    <button type="button" class="btn btn-secondary me-1" @click="changePassword()">Cancel</button>
                    <button id="saveEdit" name="saveEdit" class="btn btn-primary" @click="savePassword()">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function () {
            vue = new Vue({
                el: '#main', 
                data: {
                    isEdit: false,
                    changePass: false,

                    editUsername: '',
                    editEmail: '',

                    editOldPass: '',
                    editNewPass: '',
                    editConfirmPassword: '',
                },
                methods: {
                    editProfile() {
                        this.isEdit = !this.isEdit
                    },
                    changePassword() {
                        this.isEdit = false
                        this.changePass = !this.changePass
                    },
                    // GET Client By Id
                    getClientById(id) {
                        // Store reference to the Vue component instance
                        const vm = this

                        $.ajax({
                            type: 'GET',
                            data: {
                                client_id: client_id,
                            },
                            url: '../api/client/get_client_id.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                vm.editUsername = data.username
                                vm.editEmail = data.email
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                reject(error)
                            }
                        });
                    },
                    // Save edited profile username and email
                    saveEditProfile() {
                        const vm = this
                        
                        if (this.editUsername != '' && this.editEmail != '') {
                            $.ajax({
                                type: 'POST',
                                data: {
                                    id: client_id,
                                    username: this.editUsername,
                                    email: this.editEmail
                                },
                                url: '../api/client/edit_client_username.php',
                                success: function(res) {
                                    data = JSON.parse(res)

                                    // If there is no error
                                    if (data['error'] == 0) {
                                        // Reset data
                                        vm.getClientById()
                                        
                                        Swal.fire({
                                            title:'Success', 
                                            icon:'success', 
                                            text: data['msg'], 
                                            allowOutsideClick: false,
                                            confirmButtonText:'OK', 
                                            willClose:() => {
                                                window.location='logout.php';
                                            }
                                        });
                                    } else if (data['error'] == 1) {
                                        Swal.fire({
                                            title: 'Error',
                                            text: data['msg'],
                                            icon: 'error',
                                            allowOutsideClick: false,
                                            confirmButtonText:'Close',
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    // Handle error
                                    console.log('Error:', error)
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Please fill in all the input fields!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    },
                    // Edit profile password
                    savePassword() {
                        const vm = this
                        
                        if (this.editOldPass != '' && this.editNewPass != '' && this.editConfirmPassword != '') {
                            if (this.editNewPass == this.editConfirmPassword) {
                                $.ajax({
                                    type: 'POST',
                                    data: {
                                        id: client_id,
                                        old_password: this.editOldPass,
                                        new_password: this.editNewPass
                                    },
                                    url: '../api/client/edit_client_password.php',
                                    success: function(res) {
                                        data = JSON.parse(res)
                                        
                                        // Reset input fields
                                        vm.editOldPass = ''
                                        vm.editNewPass = ''
                                        vm.editConfirmPassword = ''
                                        
                                        vm.changePass = false

                                        // If there is no error
                                        if (data['error'] == 0) {
                                            Swal.fire({
                                                title:'Success', 
                                                icon:'success', 
                                                text: data['msg'], 
                                                allowOutsideClick: false,
                                                confirmButtonText:'OK',
                                                willClose:() => {
                                                    window.location='logout.php';
                                                } 
                                            });
                                        } else if (data['error'] == 1) {
                                            Swal.fire({
                                                title: 'Error',
                                                text: data['msg'],
                                                icon: 'error',
                                                allowOutsideClick: false,
                                                confirmButtonText:'Close',
                                            });
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        // Handle error
                                        console.log('Error:', error)
                                    }
                                });
                            } else {
                                Swal.fire({
                                    title: 'Error',
                                    text: 'Password did not match!',
                                    icon: 'error',
                                    allowOutsideClick: false,
                                    confirmButtonText:'Close'
                                });
                            }
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Please fill in all the input fields!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    },
                },
                mounted() {
                    this.getClientById(client_id)
                }
            });
        });
    </script>
</body>
</html>