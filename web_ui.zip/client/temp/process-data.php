<?php
session_start();

$id = $_SESSION['id'];
// $id = 2;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $url = 'http://localhost:8087/order';

    $client_id = $id;
    $event_type_id = $_POST['event'];
    $status = 0;
    $contact = $_POST['contact'];
    $date = $_POST['date'] ." ".$_POST['time'];
    $location = $_POST['location'];

    $data = [
        'client_id' => $client_id,
        'event_type_id' => $event_type_id, 
        'status' => $status, 
        'contact' => $contact, 
        'date' => $date, 
        'location' => $location
    ];

    // $data = file_get_contents('php://input');
    $options = [
        'http' => [
            'header' => "Content-Type: application/json\r\n",
            'method' => 'POST',
            'content' => json_encode($data),
        ],
    ];
    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);

    if ($response === false) {
        // Handle error
        echo "Error: " . error_get_last()['message'];
    } else {
        // Parse the JSON response
        $data_user = json_decode($response, true);

        // Handle the response data
        if (isset($data_user['id'])) {
            header("location: index.php");
            // $username = $data_user['id'];
            // echo "<script>alert('id: " . $data['location'] . "');</script>";
        } else {
            echo "<script>alert('No id found.');</script>";
        }
    }
}
?>