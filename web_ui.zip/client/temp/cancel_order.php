<?php
// session_start();

// $id = $_SESSION['id'];
// $id = 2;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id_order = $_POST['id_order'];
    $url = 'http://localhost:8087/order/' . $id_order;

    $options = [
        'http' => [
            'method' => 'DELETE',
            'header' => 'Content-type: application/x-www-form-urlencoded',
        ],
    ];
    
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    
    if ($result === false) {
        echo "Error"; 
    } else {
        echo "Your order has succesfully been deleted";
    }
}
?>