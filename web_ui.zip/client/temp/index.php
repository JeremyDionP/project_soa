<?php
    include 'links.php';
    include 'navbar.php';

    session_start();

    if(!isset($_SESSION['username'])){
        header('Location: ../index.php');
    }
    
    $id = $_SESSION['id'];

    // $id = 2;
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <style>
    body {
      /* padding: 20px; */
      background-color: #D4D4CE;
    }

    h1 {
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px;
    }

    th,
    td {
      padding: 8px;
      border: 1px solid #ddd;
    }
  </style>
</head>

<body>

<div class="container">
    <!-- <h1 class="mt-5">Your Orders</h1> -->
    <div class="row mt-5">
        <div class="col-6">
            <h1>Your Orders</h1>
        </div>
        <div class="col-6" style="text-align: right;">
            <!-- <a href="make_order.php"> -->
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#makeOrder" style="background-color: #287094;">(+) Make Order </button>
            <!-- </a> -->
        </div>
    </div>

    <div class="modal fade" id="makeOrder" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Make Your Order!</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="edit-profile-form" class="mt-5" method="post" action="process-data.php">
                    <div class="mb-3">
                        <label for="event" class="form-label">Event Type</label>
                        <select class="form-control" id="event" name="event">
                            <?php
                            $url2 = 'http://localhost:8087/order/type';
                            $options2 = [
                                'http' => [
                                    'header' => "Content-Type: application/json\r\n",
                                    'method' => 'GET',
                                ],
                            ];
                            $context2 = stream_context_create($options2);
                            $response2 = file_get_contents($url2, false, $context2);
                            if ($response2 === false) {
                                // Handle error
                                echo "Error: " . error_get_last()['message'];
                            } else {
                                $data_type = json_decode($response2, true);

                                if ($data_type !== false) {
                                    foreach ($data_type as $type) {
                                        echo "<option value=". $type['id'] . ">" . $type['type'] . "</option>";
                                    }
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="contact" class="form-label">Contact Number</label>
                        <input type="tel" class="form-control" id="contact" name="contact" required>
                    </div>
                    <div class="mb-3">
                        <label for="date" class="form-label">Date</label>
                        <input type="date" class="form-control" id="date" name="date" required>
                    </div>
                    <div class="mb-3">
                        <label for="time" class="form-label">Time</label>
                        <input type="time" class="form-control" id="time" name="time" required>
                    </div>
                    <div class="mb-3">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="location" name="location" required>
                    </div>
                    <button type="submit" class="btn btn-primary" id="btnSubmit">Order</button>
                </form>
            </div>
            <div class="modal-footer">
                <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
            </div>
        </div>
    </div>

    <table>
    <thead>
        <tr>
            <th>Event Type</th>
            <th>Status</th>
            <th>Contact</th>
            <th>Date </th>
            <th>Time</th>
            <th>Location</th>
            <th>Details</th>
        </tr>
    </thead>
    <tbody id="orders-table-body">
        <?php
            $url = 'http://localhost:8087/order';
            $options = [
                'http' => [
                    'header' => "Content-Type: application/json\r\n",
                    'method' => 'GET',
                ],
            ];
            $context = stream_context_create($options);
            $response = file_get_contents($url, false, $context);
            if ($response === false) {
                // Handle error
                echo "Error: " . error_get_last()['message'];
            } else {
              // Parse the JSON response
              $data = json_decode($response, true);
              if ($data !== false) {
                foreach ($data as $order) {
                    $orderId = $order['id'];
                    if($id === $order['client_id']){
                        echo "<tr>";

                        //get event name by its id
                        $url2 = 'http://localhost:8087/order/type';
                        $options2 = [
                            'http' => [
                                'header' => "Content-Type: application/json\r\n",
                                'method' => 'GET',
                            ],
                        ];
                        $context2 = stream_context_create($options2);
                        $response2 = file_get_contents($url2, false, $context2);
                        if ($response2 === false) {
                            // Handle error
                            echo "Error: " . error_get_last()['message'];
                        } else {
                            $data_type = json_decode($response2, true);

                            if ($data_type !== false) {
                                foreach ($data_type as $type) {
                                    // echo "<td>". $type['type'] . "</td>";
                                    if($type['id'] === $order['event_type_id']){
                                        echo "<td>" . $type['type'] . "</td>";
                                    }
                                }
                            }
                        }
                        $datetime = explode(" ", $order['date']);

                        if($order['status'] == 0){
                            echo "<td>Not Approved</td>";
                        }else{
                            echo "<td>Approved</td>";
                        }
                        echo "<td>" . $order['status'] . "</td>";
                        echo "<td>" . $order['contact'] . "</td>";
                        echo "<td>" . $datetime[0] . "</td>";
                        echo "<td>" . $datetime[1] . "</td>";
                        // echo "<td>" . $order['date'] . "</td>";
                        echo "<td>" . $order['location'] . "</td>";
                        if($order['status'] == 0){
                            echo '<td> <button type="button" class="btn btn-danger btn_cancel" id=' . $orderId . ' style="background-color: #A23A34;">Cancel Order</button></td>';
                        }else{
                            echo '<td> <button type="button" class="btn btn-primary btn_view" id=' . $orderId . ' style="background-color: #287094;" data-bs-toggle="modal" data-bs-target="#myModal">View Rundown</button></td>';
                        }
                        echo "</tr>";
                    }
                }
              } else {
                echo 'Failed to encode JSON.';
              }
            }
        ?>
    </tbody>
    </table>

    <!-- <div class="row justify-content-center">
        <div class="col mx-auto">
            <a href="make_order.php">
                <button class="btn btn-primary">Make Order </button>
            </a>
        </div>
    </div> -->
</div>

<div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Event Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="modal-body-rundown">
        
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div>
  </div>
</div>
    

  <!-- Bootstrap JS (Place at the end of the body) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function(){
        $(".btn_view").click(function(){
            // alert(this.id);

            fetch('load-rundown.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({id: this.id})
            })
                .then(response => response.json())
                .then(data => {
                    // console.log(data);
                    const jsonData = JSON.parse(data);
                    // console.log(jsonData[0]['time_start'], jsonData[0]['time_end'], jsonData[0]['description']);
                    var modalBody = $("#modal-body-rundown");

                    var row = $("<div>").addClass("row mb-2 mt-4");

                    // Create Bootstrap columns for time start, time end, and description
                    var colTimeStart = $("<h5>").addClass("col").text("Time Start");
                    var colTimeEnd = $("<h5>").addClass("col").text("Time End");
                    var colDescription = $("<h5>").addClass("col").text("Description");

                    // Append the columns to the row
                    row.append(colTimeStart, colTimeEnd, colDescription);

                    // Append the row to the modal body
                    modalBody.append(row);

                    for (var key in jsonData) {
                        if (jsonData.hasOwnProperty(key)) {
                            var value = jsonData[key];
                            console.log(value['time_start'], value['time_end'], value['description']);

                            var row = $("<div>").addClass("row");

                            // Create Bootstrap columns for time start, time end, and description
                            var colTimeStart = $("<div>").addClass("col").text(value['time_start']);
                            var colTimeEnd = $("<div>").addClass("col").text(value['time_end']);
                            var colDescription = $("<div>").addClass("col").text(value['description']);

                            // Append the columns to the row
                            row.append(colTimeStart, colTimeEnd, colDescription);

                            // Append the row to the modal body
                            modalBody.append(row);
                        }
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        });

        $(".btn_cancel").click(function(){
            var buttonId = $(this).attr("id");

            $.ajax({
                url: "cancel_order.php",
                type: "POST",
                data: { id_order: buttonId },
                success: function(response) {
                    alert(response);
                    location.reload();
                },
                error: function(xhr, status, error) {
                    alert("Error deleting resource: " + xhr.status);
                    // Handle errors
                }
            });
        });

        $('#myModal').on('hidden.bs.modal', function () {
            var modalBody = $("#modal-body-rundown");
            modalBody.empty();
        })
    });
  </script>
</body>

</html>
