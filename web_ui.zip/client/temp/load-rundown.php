<?php
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'];
    // echo $id;
    $url2 = 'http://localhost:8089/event/order/'.$id;
    $options2 = [
        'http' => [
            'header' => "Content-Type: application/json\r\n",
            'method' => 'GET',
        ],
    ];
    $context2 = stream_context_create($options2);
    $response2 = file_get_contents($url2, false, $context2);
    if ($response2 === false) {
        // Handle error
        echo "Error: " . error_get_last()['message'];
    } else {
        $data_type = json_encode($response2);
        echo $data_type;
        // echo $response2;

        // if ($data_type !== false) {
        //     foreach ($data_type as $type) {
        //         echo $type['time_start'] . ' ' . $type['time_end'] . ' ' . $type['description'];
        //         echo '<br>';
        //     }
        // }
    }
?>