<?php
    include 'links.php';
    include 'navbar.php';
    
    session_start();

    if(!isset($_SESSION['username'])){
        header('Location: ../index.php');
    }
    
    $id = $_SESSION['id'];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Get the raw PUT data
        $url = 'http://localhost:8081/client/' . $id;
    
    
        $data = [
            'username' => $_POST['username'],
            'email' => $_POST['email']
            // 'password' => $_POST['password'], 
            // 'role' => 0
        ];
    
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
        $response = curl_exec($ch);
    
    
        if ($response === false) {
            echo "Error: " . curl_error($ch);
        } else {
            $data_user = json_decode($response, true);
            // echo 'console.log(' . json_encode($data_user) . ');';
            if (isset($data_user['event'])) {
                echo "<script>alert('Data Updated');</script>";
                // header("Location: update_profile.php");
                exit();
            } else {
                echo "<script>alert('No id found.'); window.location.href = 'index.php';</script>";
            }
        }
    
        curl_close($ch);
        
      }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit User Profile</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <style>
    body {
      /* padding: 20px; */
      background-color: #D4D4CE;
    }
    #cont {
      max-width: 400px;
      margin: 50px auto;
    }
  </style>
</head>

<body>
  <div class="container" id="cont">
    <h1 class="mb-3">Edit Your Profile</h1>

    <!-- <div class="row mb-5">
        <div class="col-6"></div>
        <div class="col-6" style="text-align: right;">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#makeOrder">Change Password</button>
        </div>
    </div> -->

    <?php
      $url = 'http://localhost:8081/client/' . $id;
      $options = [
          'http' => [
              'header' => "Content-Type: application/json\r\n",
              'method' => 'GET',
          ],
      ];
      $context = stream_context_create($options);
      $response = file_get_contents($url, false, $context);
      if ($response === false) {
          // Handle error
          echo "Error: " . error_get_last()['message'];
      } else {
        // Parse the JSON response
        $data_user = json_decode($response, true);

        // $username = "";
        // Handle the response data
        if (isset($data_user['username'])) {
          $username = $data_user['username'];
          $email = $data_user['email'];
          $password = $data_user['password'];
          // echo "alert('Username: " . $username . "');";
        }else {
          echo "No username found.";
        }
      }
    ?>

    <!-- Edit Profile Form -->
    <form id="edit-profile-form" method="post" action="">
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" value="<?php echo $username ?>" class="form-control" id="username" name="username" required>
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" value="<?php echo $email ?>" class="form-control" id="email" name="email" required>
      </div>
      <a href="change_pass.php">
        <p style="text-align: center">Change Your Password</p>
      </a>

      <div class="text-center">
      <button type="submit" class="btn btn-primary mt-3" id="btnSubmit" style="background-color: #287094;">Save Changes</button>
    </div>
    </form>
  </div>

  <!-- Bootstrap JS (Place at the end of the body) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function(){
      $("#btnSubmit").click(function(){
          
      })
    })
  </script>
</body>

</html>
