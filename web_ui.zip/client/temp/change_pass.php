<?php
    include 'links.php';
    include 'navbar.php';
    
    session_start();

    if(!isset($_SESSION['username'])){
        header('Location: ../index.php');
    }
    
    $id = $_SESSION['id'];

    // $id = 2;


    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Get the raw PUT data
        $url = 'http://localhost:8081/client/password/' . $id;
    
        $old_pass = $_POST['old-password'];
        $new_pass = $_POST['password'];
        $conf_pass = $_POST['confirm-password'];
    
    
        $result = strcmp($new_pass, $conf_pass);
    
        if ($result == 0) {
            // echo "The strings are equal.";
            $data = [
                'old_password' => $old_pass,
                'new_password' => $new_pass
            ];
        
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        
            $response = curl_exec($ch);
        
        
            if ($response === false) {
                echo "Error: " . curl_error($ch);
            } else {
                $data_user = json_decode($response, true);
                if (isset($data_user['error'])) {
                    echo "<script>alert('" . $data_user['error'] . "');</script>";
                }else{
                    echo "<script>alert('Password changed'); </script>";
                }
            }
        
            curl_close($ch);
        } else {
            echo "<script>alert('Password does not match');</script>";
        }
    
        
        
      }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Change Password</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <style>
    .container {
      max-width: 400px;
      margin: 50px auto;
    }
    body {
      /* padding: 20px; */
      background-color: #D4D4CE;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1 class="mb-3">Change Password</h1>

    <?php
      $url = 'http://localhost:8081/client/' . $id;
      $options = [
          'http' => [
              'header' => "Content-Type: application/json\r\n",
              'method' => 'GET',
          ],
      ];
      $context = stream_context_create($options);
      $response = file_get_contents($url, false, $context);
      if ($response === false) {
          // Handle error
          echo "Error: " . error_get_last()['message'];
      } else {
        // Parse the JSON response
        $data_user = json_decode($response, true);

        // $username = "";
        // Handle the response data
        if (isset($data_user['username'])) {
          $username = $data_user['username'];
          $email = $data_user['email'];
          $password = $data_user['password'];
          // echo "alert('Username: " . $username . "');";
        }else {
          echo "No username found.";
        }
      }
    ?>

    <!-- Edit Profile Form -->
    <form id="edit-profile-form" method="post" action="">
      <div class="mb-3">
        <label for="password" class="form-label">Old Password</label>
        <input type="password" class="form-control" id="old-password" name="old-password" required>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">New Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
      <div class="mb-3">
        <label for="confirm-password" class="form-label">Confirm Password</label>
        <input type="password" class="form-control" id="confirm-password" name="confirm-password" required>
      </div>
      <div class="text-center">
        <button type="submit" class="btn btn-primary mt-5" id="btnSubmit" style="background-color: #287094;">Change Password</button>
    </div>
    </form>
  </div>

  <!-- Bootstrap JS (Place at the end of the body) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
