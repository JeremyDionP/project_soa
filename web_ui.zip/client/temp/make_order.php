<?php
    include 'links.php';
    include 'navbar.php';
    session_start();

    if(!isset($_SESSION['id'])){
        header('Location: ../index.php');
    }
    $id = $_SESSION['id'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Make Order</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <style>
    .container {
      max-width: 400px;
      margin: 50px auto;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Make an Order</h1>
  <form id="edit-profile-form" class="mt-5" method="post" action="process-data.php">
      <div class="mb-3">
        <label for="event" class="form-label">Event Type</label>
        <select class="form-control" id="event" name="event">
            <?php
              $url2 = 'http://localhost:8087/order/type';
              $options2 = [
                  'http' => [
                      'header' => "Content-Type: application/json\r\n",
                      'method' => 'GET',
                  ],
              ];
              $context2 = stream_context_create($options2);
              $response2 = file_get_contents($url2, false, $context2);
              if ($response2 === false) {
                  // Handle error
                  echo "Error: " . error_get_last()['message'];
              } else {
                  $data_type = json_decode($response2, true);

                  if ($data_type !== false) {
                      foreach ($data_type as $type) {
                        echo "<option value=". $type['id'] . ">" . $type['type'] . "</option>";
                      }
                  }
              }
            ?>
        </select>
      </div>
      <div class="mb-3">
        <label for="contact" class="form-label">Contact Number</label>
        <input type="tel" class="form-control" id="contact" name="contact" required>
      </div>
      <div class="mb-3">
        <label for="date" class="form-label">Date</label>
        <input type="date" class="form-control" id="date" name="date" required>
      </div>
      <div class="mb-3">
        <label for="time" class="form-label">Time</label>
        <input type="time" class="form-control" id="time" name="time" required>
      </div>
      <div class="mb-3">
        <label for="location" class="form-label">Location</label>
        <input type="text" class="form-control" id="location" name="location" required>
      </div>
      <button type="submit" class="btn btn-primary" id="btnSubmit">Order</button>
    </form>
  </div>

  <!-- Bootstrap JS (Place at the end of the body) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function(){
    })
  </script>
</body>

</html>
