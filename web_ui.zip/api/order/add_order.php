<?php
    if (isset($_POST['client_id']) && isset($_POST['event_type_id']) && isset($_POST['contact']) && isset($_POST['date']) && isset($_POST['location'])) {
        // Retrieve POST data
        $client_id = $_POST['client_id'];
        $event_type_id = $_POST['event_type_id'];
        $contact = $_POST['contact'];
        $date = $_POST['date'];
        $location = $_POST['location'];
        
        // Perform validations
        if (empty($client_id) || empty($event_type_id) || empty($contact) || empty($date) || empty($location)) {
            $res =  array('error' => 1, 'msg'=> 'Please fill in all the input fields!');
            echo json_encode($res);
        } else {
            // URL to send the POST request to
            $url = 'http://localhost:8087/order';

            // Data to be sent in the POST request
            $data = [
                'client_id' => $client_id,
                'event_type_id' => $event_type_id,
                'status' => 0,
                'contact' => $contact,
                'date' => $date,
                'location' => $location,
            ];

            $curl = curl_init($url);

            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));

            // Execute the cURL request
            $response = curl_exec($curl);
            $data = json_decode($response, true);

            // Check for errors
            if ($response === false) {
                $res = array('error' => 1, 'msg' => 'An error occurred, please try again.');
            } else {
                // $id = $data["id"];
                if (array_key_exists('error', $data)) {
                    $res = array('error' => 1, 'msg' => $data['error']);
                } else {
                    $res = array('error' => 0, 'msg' => 'New event type has been created!');
                }
            }
            
            curl_close ($curl);
            echo json_encode($res);
        }
    }    
?>