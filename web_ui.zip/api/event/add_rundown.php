<?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // URL to send the POST request to
        $url = 'http://localhost:8089/event/order/'.$_POST['order_id'];

        $curl = curl_init($url);

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $_POST['list_rundown']);

        // Execute the cURL request
        $response = curl_exec($curl);
        $data = json_decode($response, true);

        // Check for errors
        if ($response === false) {
            $res = array('error' => 1, 'msg' => 'An error occurred, please try again.');
        } else {
            if (array_key_exists('error', $data)) {
                $res = array('error' => 1, 'msg' => $data['error']);
            } else {
                $res = array('error' => 0, 'msg' => 'Rundown has been added!');
            }
        }
        
        curl_close ($curl);
        echo json_encode($res);
    }
?>