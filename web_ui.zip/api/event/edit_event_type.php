<?php
    if (isset($_POST['id']) && isset($_POST['type'])) {
        // Retrieve POST data
        $id = $_POST['id'];
        $type = $_POST['type'];
        
        // Perform validations
        if (empty($id) || empty($type)) {
            $res =  array('error' => 1, 'msg'=> 'Please fill in all the input fields!');
            echo json_encode($res);
        } else {
            // URL to send the PUT request to
            $url = 'http://localhost:8089/event/type/'.$id;

            // Data to be sent in the PUT request
            $data = [
                'event_type' => $type
            ];

            // Initialize cURL
            $curl = curl_init($url);

            // Set the cURL options
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT'); // Use PUT method for update
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));

            // Execute the cURL request
            $response = curl_exec($curl);
            $data = json_decode($response, true);

            // Check for errors
            if ($response === false) {
                $res = array('error' => 1, 'msg' => 'An error occurred, please try again.');
            } else {
                $res = array('error' => 0, 'msg' => 'Event type successfully updated!');
            }
            
            curl_close ($curl);
            echo json_encode($res);
        }
    }    
?>