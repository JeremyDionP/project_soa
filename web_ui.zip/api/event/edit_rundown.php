<?php
    if (isset($_POST['id']) && isset($_POST['order_id']) && isset($_POST['event_type_id']) && isset($_POST['time_start']) && isset($_POST['time_end']) && isset($_POST['description']) && isset($_POST['pic'])) {
        // Retrieve POST data
        $id = $_POST['id'];
        $order_id = $_POST['order_id'];
        $event_type_id = $_POST['event_type_id'];
        $time_start = $_POST['time_start'];
        $time_end = $_POST['time_end'];
        $description = $_POST['description'];
        $pic = $_POST['pic'];
        
        // Perform validations
        if (empty($id) || empty($order_id) || empty($event_type_id) || empty($time_start) || empty($time_end) || empty($description) || empty($pic)) {
            $res =  array('error' => 1, 'msg'=> 'Please fill in all the input fields!');
            echo json_encode($res);
        } else {
            // URL to send the PUT request to
            $url = 'http://localhost:8089/event/'.$id;

            // Data to be sent in the PUT request
            $data = [
                'order_id' => $order_id,
                'event_type_id' => $event_type_id,
                'time_start' => $time_start,
                "time_end" => $time_end,
                "description" => $description,
                "pic" => $pic,
            ];

            // Initialize cURL
            $curl = curl_init($url);

            // Set the cURL options
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT'); // Use PUT method for update
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));

            // Execute the cURL request
            $response = curl_exec($curl);
            $data = json_decode($response, true);

            // Check for errors
            if ($response === false) {
                $res = array('error' => 1, 'msg' => 'An error occurred, please try again.');
            } else {
                $res = array('error' => 0, 'msg' => 'Rundown successfully updated!');
            }
            
            curl_close ($curl);
            echo json_encode($res);
        }
    }    
?>