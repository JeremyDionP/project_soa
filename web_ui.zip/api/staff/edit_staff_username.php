<?php
    if (isset($_POST['id']) && isset($_POST['username']) && isset($_POST['email'])) {
        // Retrieve POST data
        $id = $_POST['id'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        
        // Perform validations
        if (empty($id) || empty($username) || empty($email)) {
            $res =  array('error' => 1, 'msg'=> 'Please fill in all the input fields!');
            echo json_encode($res);
        } else {
            // URL to send the PUT request to
            $url = 'http://localhost:8083/staff/'.$id;

            // Data to be sent in the PUT request
            $data = [
                'username' => $username,
                'email' => $email
            ];

            // Initialize cURL
            $curl = curl_init($url);

            // Set the cURL options
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT'); // Use PUT method for update
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));

            // Execute the cURL request
            $response = curl_exec($curl);
            $data = json_decode($response, true);

            // Check for errors
            if ($response === false) {
                $res = array('error' => 1, 'msg' => 'An error occurred, please try again.');
            } else {
                $res = array('error' => 0, 'msg' => 'Staff successfully updated!');
            }
            
            curl_close ($curl);
            echo json_encode($res);
        }
    }    
?>