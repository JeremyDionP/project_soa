<?php
    if (isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password'])) {
        // Retrieve POST data
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        
        // Perform validations
        if (empty($username) || empty($password)) {
            $res =  array('error' => 1, 'msg'=> 'Please fill in all the input fields!');
            echo json_encode($res);
        } else {
            // URL to send the POST request to
            $url = 'http://localhost:8083/staff';

            // Data to be sent in the POST request
            $data = [
                'username' => $username,
                'password' => $password,
                'email' => $email,
                "role" => 1
            ];

            $curl = curl_init($url);

            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));

            // Execute the cURL request
            $response = curl_exec($curl);
            $data = json_decode($response, true);

            // Check for errors
            if ($response === false) {
                $res = array('error' => 1, 'msg' => 'An error occurred, please try again.');
            } else {
                // $id = $data["id"];
                if (array_key_exists('error', $data)) {
                    $res = array('error' => 1, 'msg' => $data['error']);
                } else {
                    $res = array('error' => 0, 'msg' => 'New account has been created!');
                }
            }
            
            curl_close ($curl);
            echo json_encode($res);
        }
    }    
?>