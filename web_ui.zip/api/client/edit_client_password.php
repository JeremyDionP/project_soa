<?php
    if (isset($_POST['id']) && isset($_POST['old_password']) && isset($_POST['new_password'])) {
        // Retrieve POST data
        $id = $_POST['id'];
        $old_password = $_POST['old_password'];
        $new_password = $_POST['new_password'];
        
        // Perform validations
        if (empty($id) || empty($old_password) || empty($new_password)) {
            $res =  array('error' => 1, 'msg'=> 'Please fill in all the input fields!');
            echo json_encode($res);
        } else {
            // URL to send the PUT request to
            $url = 'http://localhost:8081/client/password/'.$id;

            // Data to be sent in the PUT request
            $data = [
                'old_password' => $old_password,
                'new_password' => $new_password
            ];

            // Initialize cURL
            $curl = curl_init($url);

            // Set the cURL options
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT'); // Use PUT method for update
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));

            // Execute the cURL request
            $response = curl_exec($curl);
            $data = json_decode($response, true);

            // Check for errors
            if ($response === false) {
                $res = array('error' => 1, 'msg' => 'An error occurred, please try again.');
            } else {
                if (array_key_exists('error', $data)) {
                    $res = array('error' => 1, 'msg' => $data['error']);
                } else {
                    $res = array('error' => 0, 'msg' => '
                    Your password has been changed successfully, please re-login using your new password!');
                }
            }
            
            curl_close ($curl);
            echo json_encode($res);
        }
    }    
?>