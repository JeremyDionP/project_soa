<?php
    if (isset($_POST['id']) && isset($_POST['username']) && isset($_POST['email'])) {
        // Retrieve POST data
        $id = $_POST['id'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        
        // Perform validations
        if (empty($id) || empty($username) || empty($email)) {
            $res =  array('error' => 1, 'msg'=> 'Please fill in all the input fields!');
            echo json_encode($res);
        } else {
            // URL to send the PUT request to
            $url = 'http://localhost:8081/client/'.$id;

            // Data to be sent in the PUT request
            $data = [
                'username' => $username,
                'email' => $email
            ];

            // Initialize cURL
            $curl = curl_init($url);

            // Set the cURL options
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT'); // Use PUT method for update
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));

            // Execute the cURL request
            $response = curl_exec($curl);
            $data = json_decode($response, true);

            // Check for errors
            if ($response === false) {
                $res = array('error' => 1, 'msg' => 'An error occurred, please try again.');
            } else {
                if (array_key_exists('error', $data)) {
                    $res = array('error' => 1, 'msg' => $data['error']);
                } else {
                    // Update SESSION username
                    $_SESSION['username'] = $username;

                    $res = array('error' => 0, 'msg' => 'Your profile updated successfully, please re-login using your new updated profile!');
                }
            }
            
            curl_close ($curl);
            echo json_encode($res);
        }
    }    
?>