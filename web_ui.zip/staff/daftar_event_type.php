<?php
    session_start();

    if(!isset($_SESSION['username'])){
        header('Location: ../index.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php include 'links.php'; ?>

    <title>Daftar Event Type</title>
</head>
<body>
    <div id="main">
        <?php include 'navbar.php'; ?>
        
        <div class="container">
            <!-- Add Staff -->
            <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addEventTypeModal">+ Add Event Type</button>

            <!-- Staff Table -->
            <table id="event-type-table" class="table table-light" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Event Type</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="staff-table-body">
                    <tr v-for="(type, index) in listEventType" :key="type.id">
                        <td>{{ index+1 }}</td>
                        <td>{{ type.type }}</td>
                        <td><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editEventTypeModal" @click="getEventTypeById(type.id)">Edit</button> <button type="button" class="btn btn-danger" @click="deleteEventType(type.id)">Delete</button></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Add Event Type Modal -->
        <div class="modal fade" id="addEventTypeModal" tabindex="-1" aria-labelledby="addEventTypeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addEventTypeModalLabel">Add New Event Type</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Type -->
                        <div class="mb-3">
                            <label for="addType" class="form-label">Type</label>
                            <input v-model="addType" id="addType" type="text" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" @click="addEventType()">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Event Type Modal -->
        <div class="modal fade" id="editEventTypeModal" tabindex="-1" aria-labelledby="editEventTypeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editEventTypeModalLabel">Edit Event Type</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Type -->
                        <div class="mb-3">
                            <label for="editType" class="form-label">Type</label>
                            <input v-model="editType" id="editType" type="text" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" @click="editEventType()">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        $(document).ready(function () {
            // Bootstrap DataTable initialization
            $('#event-type-table').DataTable()

            vue = new Vue({
                el: '#main', 
                data: {
                    listEventType: '',

                    
                    addType: '',

                    editId: '',
                    editType: ''
                },
                methods: {
                    getEventType() {
                        // Store reference to the Vue component instance
                        const vm = this

                        // reset list
                        this.listEventType = []

                        $.ajax({
                            type: 'GET',
                            url: '../api/order/get_event_type.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                vm.listEventType = data
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        });
                    },
                    getEventTypeById(id) {
                        for (var i = 0; i < this.listEventType.length; i++) {
                            if (this.listEventType[i].id == id) {
                                this.editType = this.listEventType[i].type
                                this.editId = id
                            }
                        }
                    },
                    addEventType() {
                        // Store reference to the Vue component instance
                        const vm = this
                        
                        if (this.addType != '') {
                            $.ajax({
                                type: 'POST',
                                data: {
                                    type: this.addType,
                                },
                                url: '../api/event/add_event_type.php',
                                success: function(res) {
                                    data = JSON.parse(res)

                                    // If there is no error
                                    if (data['error'] == 0) {
                                        Swal.fire({
                                            title:'Success', 
                                            icon:'success', 
                                            text: data['msg'], 
                                            allowOutsideClick: false,
                                            confirmButtonText:'OK', 
                                        });

                                        // Reset input fields
                                        vm.addType = ''

                                        // Reset table
                                        vm.getEventType()

                                        // Close modal
                                        $('#addEventTypeModal').modal('toggle');
                                    } else if (data['error'] == 1) {
                                        Swal.fire({
                                            title: 'Error',
                                            text: data['msg'],
                                            icon: 'error',
                                            allowOutsideClick: false,
                                            confirmButtonText:'Close',
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    // Handle error
                                    console.log('Error:', error)
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Please fill in all the input fields!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    },
                    editEventType() {
                        const vm = this
                        
                        if (this.editType != '') {
                            $.ajax({
                                type: 'POST',
                                data: {
                                    id: this.editId,
                                    type: this.editType
                                },
                                url: '../api/event/edit_event_type.php',
                                success: function(res) {
                                    data = JSON.parse(res)

                                    // If there is no error
                                    if (data['error'] == 0) {
                                        Swal.fire({
                                            title:'Success', 
                                            icon:'success', 
                                            text: data['msg'], 
                                            allowOutsideClick: false,
                                            confirmButtonText:'OK', 
                                        });

                                        // Reset input fields
                                        vm.editId = ''
                                        vm.editType = ''

                                        // Reset table
                                        vm.getEventType()

                                        // Close modal
                                        $('#editEventTypeModal').modal('toggle');
                                    } else if (data['error'] == 1) {
                                        Swal.fire({
                                            title: 'Error',
                                            text: data['msg'],
                                            icon: 'error',
                                            allowOutsideClick: false,
                                            confirmButtonText:'Close',
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    // Handle error
                                    console.log('Error:', error)
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Please fill in all the input fields!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    },
                    deleteEventType(id) {
                        const vm = this

                        Swal.fire({
                            title: 'Are you sure?',
                            text: "You won't be able to revert this!",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                $.ajax({
                                    type: 'POST',
                                    data: {
                                        event_type_id: id
                                    },
                                    url: '../api/event/delete_event_type.php',
                                    success: function(res) {
                                        // refresh table
                                        vm.getEventType()

                                        Swal.fire(
                                            'Deleted!',
                                            'Event type has been deleted.',
                                            'success'
                                        )
                                    },
                                    error: function(xhr, status, error) {
                                        // Handle error
                                        console.log('Error:', error)
                                    }
                                });
                            }
                        })
                    }
                },
                mounted() {
                    this.getEventType()
                }
            })
        });
    </script>
</body>
</html>