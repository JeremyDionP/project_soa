<?php
    session_start();

    if(!isset($_SESSION['username'])){
        header('Location: ../index.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php include 'links.php'; ?>

    <title>Daftar Order</title>
</head>
<body>
    <div id="main">
        <?php include 'navbar.php'; ?>
        
        <div class="container">
            <!-- Staff Table -->
            <table v-if="dataLoaded" id="order-table" class="table table-light" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Client</th>
                        <th>Contact</th>
                        <th>Event Type</th>
                        <th>Date</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Rundown</th>
                    </tr>
                </thead>
                <tbody id="staff-table-body">
                    <tr v-for="(order, index) in listOrder" :key="order.id">
                        <td>{{ index+1 }}</td>
                        <td>{{ order.client_username }}</td>
                        <td>{{ order.contact }}</td>
                        <td>{{ order.event_type }}</td>
                        <td>{{ order.date }}</td>
                        <td>{{ order.location }}</td>
                        <td>
                            <button v-if="order.status == 0" type="button" class="btn btn-danger" @click="changeStatus(order.id, order.status)">Not Approve</button>
                            <button v-else-if="order.status == 1" type="button" class="btn btn-success" @click="changeStatus(order.id, order.status)">Approved</button>
                        </td>
                        <td>
                            <button type="button" class="btn btn-primary" @click="getRundown(order.id, order.status)" data-bs-toggle="modal" data-bs-target="#viewRundownModal">View</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- View Rundown Modal -->
        <div class="modal fade" id="viewRundownModal" tabindex="-1" aria-labelledby="viewRundownModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="viewRundownModalLabel">View Rundown Order</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Rundown Table -->
                        <table v-if="dataRundownLoaded" id="rundown-table" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Start</th>
                                    <th>End</th>
                                    <th>Description</th>
                                    <th>PIC</th>
                                    <th v-if="orderStatus != 1">Action</th>
                                </tr>
                            </thead>
                            <tbody id="staff-table-body">
                                <tr v-if="listRundown.length == 0">
                                    <td colspan="6" class="text-center">No rundown added yet.</td>
                                </tr>
                                <tr v-else v-for="(rundown, index) in listRundown" :key="rundown.id">
                                    <td>{{ index+1 }}</td>
                                    <td>{{ rundown.time_start }}</td>
                                    <td>{{ rundown.time_end }}</td>
                                    <td>{{ rundown.description }}</td>
                                    <td>{{ rundown.pic }}</td>
                                    <td v-if="orderStatus == 0">
                                        <button type="button" class="btn btn-primary" @click="getRundownById(rundown.id)" data-bs-toggle="modal" data-bs-target="#editRundownModal">Edit</button> <button type="button" class="btn btn-danger" @click="deleteRundown(rundown.id)">Delete</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <p v-else class="mb-0">There is no rundown.</p>
                    </div>
                    <div v-if="orderStatus != 1" class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRundownModal">Add Rundown</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Rundown Modal -->
        <div class="modal fade" id="editRundownModal" tabindex="-1" aria-labelledby="editRundownModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editRundownModalLabel">Edit Rundown</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Start Time -->
                        <div class="mb-3">
                            <label for="editStartTime" class="form-label">Start Time</label>
                            <input v-model="editStartTime" id="editStartTime" type="time" class="form-control" name="editStartTime" required>
                        </div>
                        <!-- End Time -->
                        <div class="mb-3">
                            <label for="editEndTime" class="form-label">End Time</label>
                            <input v-model="editEndTime" id="editEndTime" type="time" class="form-control" name="editEndTime" required>
                        </div>
                        <!-- Description -->
                        <div class="mb-3">
                            <label for="editDescription" class="form-label">Description</label>
                            <input v-model="editDescription" id="editDescription" type="text" class="form-control form-control-lg bg-light fs-6" name="editDescription" required>
                        </div>
                        <!-- PIC -->
                        <div class="">
                            <label for="editPIC" class="form-label">PIC</label>
                            <select v-model="editPIC" id="editPIC" class="form-control form-control-lg bg-light fs-6" name="editPIC" required>
                                <option disabled value="">--- Select PIC ---</option>
                                <option v-for="pic in listPIC" :value="pic.id" :key="pic.id">
                                    {{ pic.username }}
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" @click="saveEditRundown()">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Rundown Modal -->
        <div class="modal fade" id="addRundownModal" tabindex="-1" aria-labelledby="addRundownModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addRundownModalLabel">Add New Rundown</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <!--  Add Rundown Table -->
                            <table id="add-rundown-table" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Start</th>
                                        <th>End</th>
                                        <th>Description</th>
                                        <th>PIC</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="staff-table-body">
                                    <tr v-if="listAddRundown.length == 0">
                                        <td colspan="6" class="text-center">No rundown added yet.</td>
                                    </tr>
                                    <tr v-else v-for="(rundown, index) in listAddRundown" :key="rundown.id">
                                        <td>{{ index+1 }}</td>
                                        <td>{{ rundown.time_start }}</td>
                                        <td>{{ rundown.time_end }}</td>
                                        <td>{{ rundown.description }}</td>
                                        <td>{{ rundown.pic }}</td>
                                        <td>
                                            <button type="button" class="btn btn-danger" @click="deleteNewRundown(index)">Delete</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="row">
                            <!-- Start Time -->
                            <div class="col-6 mb-3">
                                <label for="addStartTime" class="form-label">Start Time</label>
                                <input v-model="addStartTime" id="addStartTime" type="time" class="form-control" name="addStartTime" required>
                            </div>
                            <!-- End Time -->
                            <div class="col-6 mb-3">
                                <label for="addEndTime" class="form-label">End Time</label>
                                <input v-model="addEndTime" id="addEndTime" type="time" class="form-control" name="addEndTime" required>
                            </div>
                            <!-- Description -->
                            <div class="col-12 mb-3">
                                <label for="addDescription" class="form-label">Description</label>
                                <input v-model="addDescription" id="addDescription" type="text" class="form-control form-control-lg bg-light fs-6" name="addDescription" placeholder="Add rundown description" required>
                            </div>
                            <!-- PIC -->
                            <div class="col-12 mb-3">
                                <label for="addPIC" class="form-label">PIC</label>
                                <select v-model="addPIC" id="addPIC" class="form-control form-control-lg bg-light fs-6" name="addPIC" required>
                                    <option disabled value="">--- Select PIC ---</option>
                                    <option v-for="pic in listPIC" :value="pic.id" :key="pic.id">
                                        {{ pic.username }}
                                    </option>
                                </select>
                            </div>
                            <!-- Button Add -->
                            <div class="col-12">
                                <button id="addNewRundown" name="addNewRundown" class="btn btn-primary btn-lg w-100 fs-6" @click="addNewRundown()">+ Add Rundown</button>
                            </div>
                        </div>
                    </div>
                    <div v-if="listAddRundown.length > 0" class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" @click="saveNewRundown()">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        $(document).ready(function () {
            // Bootstrap DataTable initialization
            $('#order-table').DataTable()

            vue = new Vue({
                el: '#main', 
                data: {
                    listOrder: [],
                    dataLoaded: false,

                    listEventType: [],

                    listRundown: [],
                    dataRundownLoaded: false,

                    orderId: '',
                    orderStatus: 0,

                    editId: '',
                    editStartTime: '',
                    editEndTime: '',
                    editDescription: '',
                    editPIC: '',
                    listPIC: [],

                    addStartTime: '',
                    addEndTime: '',
                    addDescription: '',
                    addPIC: '',

                    listAddRundown: [],
                },
                methods: {
                    // GET list of order data to display
                    getOrders() {
                        // Store reference to the Vue component instance
                        const vm = this

                        // Reset list order
                        this.listOrder = []

                        $.ajax({
                            type: 'GET',
                            url: '../api/order/get_order.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                // vm.listOrder = data
                                vm.dataLoaded = true

                                // Loop through the order list
                                data.forEach(async function(item) {
                                    // Get the client name for each order
                                    try {
                                        const clientName = await vm.getClientById(item.client_id)

                                        vm.listOrder.push({
                                            id: item.id,
                                            client_username: clientName,
                                            contact: item.contact,
                                            event_type: vm.getEventTypeName(item.event_type_id),
                                            event_type_id: item.event_type_id,
                                            date: item.date,
                                            location: item.location,
                                            status: item.status,
                                        })
                                    } catch (error) {
                                        console.error('Error:', error);
                                    }
                                });

                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        })
                    },
                    getEventType() {
                        // Store reference to the Vue component instance
                        const vm = this

                        $.ajax({
                            type: 'GET',
                            url: '../api/order/get_event_type.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                vm.listEventType = data
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        });
                    },
                    getEventTypeName(id) {
                        for (var i = 0; i < this.listEventType.length; i++) {
                            if (this.listEventType[i].id == parseInt(id)) {
                                return this.listEventType[i].type
                            }
                        }
                    },
                    // GET Client By Id
                    getClientById(id) {
                        // Store reference to the Vue component instance
                        const vm = this

                        return new Promise((resolve, reject) => {
                            $.ajax({
                                type: 'GET',
                                data: {
                                    client_id: id
                                },
                                url: '../api/client/get_client_id.php',
                                success: function(res) {
                                    data = JSON.parse(res)

                                    resolve(data.username)
                                },
                                error: function(xhr, status, error) {
                                    // Handle error
                                    reject(error)
                                }
                            });
                        });
                    },
                    // GET Rundown By Order Id
                    getRundown(id, status) {
                        // Store reference to the Vue component instance
                        const vm = this

                        $.ajax({
                            type: 'GET',
                            data: {
                                order_id: id
                            },
                            url: '../api/event/get_rundown_order_id.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                // update the data
                                vm.listRundown = data
                                vm.dataRundownLoaded = true

                                // set current order id
                                vm.orderId = id

                                // GET Status Order
                                vm.orderStatus = status
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        });
                    },
                    // GET Rundown By Order Id
                    getRundownById(id) {
                        for (var i = 0; i < this.listRundown.length; i++) {
                            if (this.listRundown[i].id == id) {
                                this.editId = id
                                this.editEventTypeId = this.listRundown[i].event_type_id
                                this.editStartTime = this.listRundown[i].time_start
                                this.editEndTime = this.listRundown[i].time_end
                                this.editDescription = this.listRundown[i].description

                                // GET selected PIC
                                this.getSelectedPIC(this.listRundown[i].pic)
                            }
                        }
                    },
                    // GET list of PIC
                    getPIC() {
                        // Store reference to the Vue component instance
                        const vm = this

                        $.ajax({
                            type: 'GET',
                            url: '../api/staff/get_staff.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                vm.listPIC = data['response']
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        });
                    },
                    // GET selected PIC
                    getSelectedPIC(id) {
                        for (var i = 0; i < this.listPIC.length; i++) {
                            if (this.listPIC[i].id == id) {
                                this.editPIC = this.listPIC[i].id
                            }
                        }
                    },
                    saveEditRundown() {
                        if (this.editStartTime != '' && this.editEndTime != '' && this.editDescription != '' && this.editPIC != '') {
                            const vm = this

                            $.ajax({
                                type: 'POST',
                                data: {
                                    id: this.editId,
                                    order_id: this.orderId,
                                    event_type_id: this.editEventTypeId,
                                    time_start: this.editStartTime,
                                    time_end: this.editEndTime,
                                    description: this.editDescription,
                                    pic: this.editPIC,
                                },
                                url: '../api/event/edit_rundown.php',
                                success: function(res) {
                                    data = JSON.parse(res)

                                    // If there is no error
                                    if (data['error'] == 0) {
                                        Swal.fire({
                                            title:'Success', 
                                            icon:'success', 
                                            text: data['msg'], 
                                            allowOutsideClick: false,
                                            confirmButtonText:'OK', 
                                        });

                                        // Reset input fields
                                        vm.editId = ''
                                        vm.editEventTypeId = ''
                                        vm.editStartTime = ''
                                        vm.editEndTime = ''
                                        vm.editDescription = ''
                                        vm.editPIC = ''

                                        // Reset table rundown
                                        // vm.getRundown(vm.orderId)

                                        // Close modal
                                        $('#editRundownModal').modal('toggle');
                                    } else if (data['error'] == 1) {
                                        Swal.fire({
                                            title: 'Error',
                                            text: data['msg'],
                                            icon: 'error',
                                            allowOutsideClick: false,
                                            confirmButtonText:'Close',
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    // Handle error
                                    console.log('Error:', error)
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Please fill in all the input fields!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    },
                    deleteRundown(id) {
                        const vm = this

                        Swal.fire({
                            title: 'Are you sure?',
                            text: "You won't be able to revert this!",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                $.ajax({
                                    type: 'POST',
                                    data: {
                                        rundown_id: id
                                    },
                                    url: '../api/event/delete_rundown.php',
                                    success: function(res) {
                                        // refresh table
                                        vm.getRundown(vm.orderId)

                                        Swal.fire(
                                            'Deleted!',
                                            'Rundown has been deleted.',
                                            'success'
                                        )
                                    },
                                    error: function(xhr, status, error) {
                                        // Handle error
                                        console.log('Error:', error)
                                    }
                                });
                            }
                        })
                    },
                    addNewRundown() {
                        if (this.addStartTime != '' && this.addEndTime != '' && this.addDescription != '' && this.addPIC != '') {
                            // event type id of the order
                            var eventTypeId = 0
                            for (var i = 0; i < this.listOrder.length; i++) {
                                if (this.listOrder[i].id == this.orderId) {
                                    eventTypeId = this.listOrder[i].event_type_id
                                }
                            }

                            // add to temporary list
                            this.listAddRundown.push({
                                event_type_id: eventTypeId,
                                time_start: this.addStartTime,
                                time_end: this.addEndTime,
                                description: this.addDescription,
                                pic: this.addPIC,
                            })

                            // reset input fields
                            this.addStartTime = ''
                            this.addEndTime = ''
                            this.addDescription = ''
                            this.addPIC = ''

                            Swal.fire({
                                title:'Success', 
                                icon:'success', 
                                text: 'Successfully added to temporary list!', 
                                allowOutsideClick: false,
                                confirmButtonText:'OK', 
                            });

                            console.log("ADD", this.listAddRundown)
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Please fill in all the input fields!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    },
                    deleteNewRundown(index) {
                        Swal.fire({
                            title: 'Are you sure?',
                            text: "You won't be able to revert this!",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                this.listAddRundown.splice(index, 1)

                                Swal.fire(
                                    'Deleted!',
                                    'Rundown has been deleted.',
                                    'success'
                                )
                            }
                        })
                    },
                    saveNewRundown() {
                        const vm = this

                        $.ajax({
                            type: 'POST',
                            data: {
                                order_id: this.orderId,
                                list_rundown: JSON.stringify(this.listAddRundown)
                            },
                            url: '../api/event/add_rundown.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                // If there is no error
                                if (data['error'] == 0) {
                                    Swal.fire({
                                        title:'Success', 
                                        icon:'success', 
                                        text: data['msg'], 
                                        allowOutsideClick: false,
                                        confirmButtonText:'OK', 
                                    });

                                    // Reset temporary list
                                    vm.listAddRundown = []

                                    // Close modal
                                    $('#addRundownModal').modal('toggle');
                                } else if (data['error'] == 1) {
                                    Swal.fire({
                                        title: 'Error',
                                        text: data['msg'],
                                        icon: 'error',
                                        allowOutsideClick: false,
                                        confirmButtonText:'Close',
                                    });
                                }
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        });
                    },
                    changeStatus(id, status) {
                        const vm = this

                        // Swal.fire({
                        //     title: 'Do you want to change this order status?',
                        //     text: "You won't be able to revert this!",
                        //     icon: 'warning',
                        //     showCancelButton: true,
                        //     confirmButtonColor: '#3085d6',
                        //     cancelButtonColor: '#d33',
                        //     confirmButtonText: 'Yes'
                        // }).then((result) => {
                        //     if (result.isConfirmed) {

                        //         Swal.fire(
                        //             'Deleted!',
                        //             'Rundown has been deleted.',
                        //             'success'
                        //         )
                        //     }
                        // })

                        $.ajax({
                            type: 'POST',
                            data: {
                                order_id: id,
                                status: (status == 0 ? 1 : 0)
                            },
                            url: '../api/event/edit_status.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                // If there is no error
                                if (data['error'] == 0) {
                                    Swal.fire({
                                        title:'Success', 
                                        icon:'success', 
                                        text: data['msg'], 
                                        allowOutsideClick: false,
                                        confirmButtonText:'OK', 
                                    });

                                    // Reset table
                                    vm.getOrders()
                                } else if (data['error'] == 1) {
                                    Swal.fire({
                                        title: 'Error',
                                        text: data['msg'],
                                        icon: 'error',
                                        allowOutsideClick: false,
                                        confirmButtonText:'Close',
                                    });
                                }
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        });
                    }
                },
                mounted() {
                    this.getOrders()
                    this.getEventType()
                    this.getPIC()
                }
            })
        });
    </script>
</body>
</html>