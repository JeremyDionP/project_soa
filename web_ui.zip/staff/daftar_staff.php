<?php
    session_start();

    if(!isset($_SESSION['username'])){
        header('Location: ../index.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php include 'links.php'; ?>

    <title>Daftar Staff</title>
</head>
<body>
    <div id="main">
        <?php include 'navbar.php'; ?>
        
        <div class="container">
            <!-- Add Staff -->
            <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addStaffModal">+ Add New Staff</button>

            <!-- Staff Table -->
            <table v-if="dataLoaded" id="staff-table" class="table table-light" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="staff-table-body">
                    <tr v-for="(staff, index) in listStaff" :key="staff.id">
                        <td>{{ index+1 }}</td>
                        <td>{{ staff.username }}</td>
                        <td>{{ staff.email }}</td>
                        <td><button type="button" class="btn btn-primary" @click="getStaffById(staff.id)" data-bs-toggle="modal" data-bs-target="#editStaffModal">Edit</button> <button v-if="staff.username != loginStaff" type="button" class="btn btn-danger" @click="deleteStaff(staff.id)">Delete</button></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Add Staff Modal -->
        <div class="modal fade" id="addStaffModal" tabindex="-1" aria-labelledby="addStaffModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addStaffModalLabel">Add New Staff</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Username -->
                        <div class="mb-3">
                            <label for="regUsername" class="form-label">Username</label>
                            <input v-model="regUsername" id="regUsername" type="text" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                        <!-- Email -->
                        <div class="mb-3">
                            <label for="regEmail" class="form-label">Email</label>
                            <input v-model="regEmail" id="regEmail" type="email" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                        <!-- Password -->
                        <div class="mb-3">
                            <label for="regPassword" class="form-label">Password</label>
                            <input v-model="regPassword" id="regPassword" type="password" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                        <!-- Confirm Password -->
                        <div>
                            <label for="regConfirmPassword" class="form-label">Confirm Password</label>
                            <input v-model="regConfirmPassword" id="regConfirmPassword" type="password" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" @click="addStaff()">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Staff Modal -->
        <div class="modal fade" id="editStaffModal" tabindex="-1" aria-labelledby="editStaffModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editStaffModalLabel">Edit Staff</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Username -->
                        <div class="mb-3">
                            <label for="editUsername" class="form-label">Username</label>
                            <input v-model="editUsername" id="editUsername" type="text" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                        <!-- Email -->
                        <div class="mb-3">
                            <label for="editEmail" class="form-label">Email</label>
                            <input v-model="editEmail" id="editEmail" type="email" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                        <!-- Button Change Password -->
                        <button id="btnChangePassword" name="btnChangePassword" class="btn btn-primary btn-lg w-100 fs-6" data-bs-toggle="modal" data-bs-target="#changePasswordModal">Change Password</button>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" @click="editStaff()">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Change Staff Password Modal -->
        <div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="changePasswordModalLabel">Change Password</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Old Password -->
                        <div class="mb-3">
                            <label for="editOldPass" class="form-label">Old Password</label>
                            <input v-model="editOldPass" id="editOldPass" type="password" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                        <!-- New Password -->
                        <div class="mb-3">
                            <label for="editNewPass" class="form-label">New Password</label>
                            <input v-model="editNewPass" id="editNewPass" type="password" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                        <!-- Confirm Password -->
                        <div>
                            <label for="editConfirmPassword" class="form-label">Confirm Password</label>
                            <input v-model="editConfirmPassword" id="editConfirmPassword" type="password" class="form-control form-control-lg bg-light fs-6" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" @click="changePassword()">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        $(document).ready(function () {
            // Bootstrap DataTable initialization
            $('#staff-table').DataTable()

            vue = new Vue({
                el: '#main', 
                data: {
                    listStaff: [],
                    dataLoaded: false,

                    loginStaff: '',
                    idStaff: '',

                    regUsername: '',
                    regEmail: '',
                    regPassword: '',
                    regConfirmPassword: '',

                    editUsername: '',
                    editEmail: '',

                    editOldPass: '',
                    editNewPass: '',
                    editConfirmPassword: '',
                },
                methods: {
                    // GET list of staff data to display
                    getStaff() {
                        // Store reference to the Vue component instance
                        const vm = this

                        $.ajax({
                            type: 'GET',
                            url: '../api/staff/get_staff.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                vm.listStaff = data['response']
                                vm.dataLoaded = true

                                vm.loginStaff = data['staff']
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        });
                    },
                    // POST new staff
                    addStaff() {
                        if (this.regUsername != '' && this.regPassword != '' && this.regConfirmPassword != '') {
                            if (this.regPassword == this.regConfirmPassword) {
                                const vm = this

                                $.ajax({
                                    type: 'POST',
                                    data: {
                                        username: this.regUsername,
                                        email: this.regEmail,
                                        password: this.regPassword
                                    },
                                    url: '../api/staff/add_staff.php',
                                    success: function(res) {
                                        data = JSON.parse(res)

                                        // If there is no error
                                        if (data['error'] == 0) {
                                            Swal.fire({
                                                title:'Success', 
                                                icon:'success', 
                                                text: data['msg'], 
                                                allowOutsideClick: false,
                                                confirmButtonText:'OK', 
                                            });

                                            // Reset input fields
                                            vm.regUsername = ''
                                            vm.regEmail = ''
                                            vm.regPassword = ''
                                            vm.regConfirmPassword = ''

                                            // Reset table
                                            vm.getStaff()

                                            // Close modal
                                            $('#addStaffModal').modal('toggle');
                                        } else if (data['error'] == 1) {
                                            Swal.fire({
                                                title: 'Error',
                                                text: data['msg'],
                                                icon: 'error',
                                                allowOutsideClick: false,
                                                confirmButtonText:'Close',
                                            });
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        // Handle error
                                        console.log('Error:', error)
                                    }
                                });
                            } else {
                                Swal.fire({
                                    title: 'Error',
                                    text: 'Password did not match!',
                                    icon: 'error',
                                    allowOutsideClick: false,
                                    confirmButtonText:'Close'
                                });
                            }
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Please fill in all the input fields!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    },
                    // GET Staff By Id
                    getStaffById(id) {
                        // Store reference to the Vue component instance
                        const vm = this

                        $.ajax({
                            type: 'GET',
                            data: {
                                staff_id: id
                            },
                            url: '../api/staff/get_staff_id.php',
                            success: function(res) {
                                data = JSON.parse(res)

                                vm.idStaff = id
                                vm.editUsername = data['username']
                                vm.editEmail = data['email']
                                vm.editPassword = data['password']
                            },
                            error: function(xhr, status, error) {
                                // Handle error
                                console.log('Error:', error)
                            }
                        });
                    },
                    // DELETE Staff
                    deleteStaff(id) {
                        const vm = this

                        Swal.fire({
                            title: 'Are you sure?',
                            text: "You won't be able to revert this!",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                $.ajax({
                                    type: 'POST',
                                    data: {
                                        staff_id: id
                                    },
                                    url: '../api/staff/delete_staff.php',
                                    success: function(res) {
                                        // refresh table
                                        vm.getStaff()

                                        Swal.fire(
                                            'Deleted!',
                                            'Staff account has been deleted.',
                                            'success'
                                        )
                                    },
                                    error: function(xhr, status, error) {
                                        // Handle error
                                        console.log('Error:', error)
                                    }
                                });
                            }
                        })
                    },
                    // Edit Staff Username and Email
                    editStaff() {
                        const vm = this
                        
                        if (this.editUsername != '' && this.editEmail != '') {
                            $.ajax({
                                type: 'POST',
                                data: {
                                    id: this.idStaff,
                                    username: this.editUsername,
                                    email: this.editEmail
                                },
                                url: '../api/staff/edit_staff_username.php',
                                success: function(res) {
                                    data = JSON.parse(res)

                                    // If there is no error
                                    if (data['error'] == 0) {
                                        Swal.fire({
                                            title:'Success', 
                                            icon:'success', 
                                            text: data['msg'], 
                                            allowOutsideClick: false,
                                            confirmButtonText:'OK', 
                                        });

                                        // Reset input fields
                                        vm.editUsername = ''
                                        vm.editEmail = ''

                                        // Reset table
                                        vm.getStaff()

                                        // Close modal
                                        $('#editStaffModal').modal('toggle');
                                    } else if (data['error'] == 1) {
                                        Swal.fire({
                                            title: 'Error',
                                            text: data['msg'],
                                            icon: 'error',
                                            allowOutsideClick: false,
                                            confirmButtonText:'Close',
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    // Handle error
                                    console.log('Error:', error)
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Please fill in all the input fields!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    },
                    // Edit Staff Password
                    changePassword() {
                        const vm = this
                        
                        if (this.editOldPass != '' && this.editNewPass != '' && this.editConfirmPassword != '') {
                            if (this.editNewPass == this.editConfirmPassword) {
                                $.ajax({
                                    type: 'POST',
                                    data: {
                                        id: this.idStaff,
                                        old_password: this.editOldPass,
                                        new_password: this.editNewPass
                                    },
                                    url: '../api/staff/edit_staff_password.php',
                                    success: function(res) {
                                        data = JSON.parse(res)

                                        // If there is no error
                                        if (data['error'] == 0) {
                                            Swal.fire({
                                                title:'Success', 
                                                icon:'success', 
                                                text: data['msg'], 
                                                allowOutsideClick: false,
                                                confirmButtonText:'OK', 
                                            });

                                            // Reset input fields
                                            vm.editOldPass = ''
                                            vm.editNewPass = ''
                                            vm.editConfirmPassword = ''

                                            // Reset table
                                            vm.getStaff()

                                            // Close modal
                                            $('#changePasswordModal').modal('toggle');
                                        } else if (data['error'] == 1) {
                                            Swal.fire({
                                                title: 'Error',
                                                text: data['msg'],
                                                icon: 'error',
                                                allowOutsideClick: false,
                                                confirmButtonText:'Close',
                                            });
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        // Handle error
                                        console.log('Error:', error)
                                    }
                                });
                            } else {
                                Swal.fire({
                                    title: 'Error',
                                    text: 'Password did not match!',
                                    icon: 'error',
                                    allowOutsideClick: false,
                                    confirmButtonText:'Close'
                                });
                            }
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Please fill in all the input fields!',
                                icon: 'error',
                                allowOutsideClick: false,
                                confirmButtonText:'Close'
                            });
                        }
                    },
                },
                mounted() {
                    this.getStaff()
                }
            })
        });
    </script>
</body>
</html>